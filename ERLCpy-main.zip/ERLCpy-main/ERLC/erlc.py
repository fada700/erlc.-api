from .Classes.client import ErlcClient


client = ErlcClient()